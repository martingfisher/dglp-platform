<?php
/**
 * Sign in. Wireframe 1a.
 *
 * Single sign-on is not built yet, so this offers what actually works rather
 * than showing buttons that do nothing.
 *
 * @var array<string,mixed> $data
 * @package DGL
 */

declare( strict_types=1 );

defined( 'ABSPATH' ) || exit;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a flag set by our own redirect, read only.
$flag    = isset( $_GET[ \DGL\Dashboard\SignIn::FLAG ] ) ? sanitize_key( wp_unslash( $_GET[ \DGL\Dashboard\SignIn::FLAG ] ) ) : '';
$message = \DGL\Dashboard\SignIn::message( $flag );
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a destination, read only and validated by wp_login_form.
$wanted  = isset( $_GET['redirect_to'] ) ? (string) wp_unslash( $_GET['redirect_to'] ) : (string) ( $data['redirect_to'] ?? home_url() );
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- an address to prefill, from the join page's own link.
$prefill = isset( $_GET['email'] ) ? sanitize_email( wp_unslash( $_GET['email'] ) ) : '';
if ( '' === $message && '' !== $prefill ) {
	$message = __( 'That address already has an account. Sign in with it below.', 'dgl-platform' );
}
?>
<?php /* No wrapper of its own: the shell already provides .dgl-dash, and nesting a second one nested the whole layout. */ ?>
	<div class="dgl-signin">
		<h1 class="dgl-page-head__title"><?php esc_html_e( 'Sign in', 'dgl-platform' ); ?></h1>

		<?php if ( '' !== $message ) : ?>
			<div class="dgl-alert" role="alert"><p><?php echo esc_html( $message ); ?></p></div>
		<?php endif; ?>
		<p class="dgl-page-head__lede"><?php esc_html_e( 'Sign in to the user area.', 'dgl-platform' ); ?></p>

		<?php /* Accounts from the old site were not carried across; say so before somebody tries one. The address follows whichever domain the site is on. */ ?>
		<p class="dgl-signin__note">
			<?php esc_html_e( "Note: Logins from our previous site won't work.", 'dgl-platform' ); ?>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: address of the join page. */
					__( 'Please <a href="%s">create a new account</a>.', 'dgl-platform' ),
					esc_url( \DGL\Dashboard\Router::url( 'join' ) )
				),
				[ 'a' => [ 'href' => [] ] ]
			);
			?>
		</p>

		<?php
		wp_login_form(
			[
				'redirect'       => $wanted,
				'label_username' => __( 'Email address', 'dgl-platform' ),
				'label_log_in'   => __( 'Sign in', 'dgl-platform' ),
				'value_username' => $prefill,
			]
		);
		?>

		<p class="dgl-signin__foot">
			<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Forgotten your password?', 'dgl-platform' ); ?></a>
		</p>
		<p class="dgl-signin__foot">
			<?php esc_html_e( 'Not a member yet?', 'dgl-platform' ); ?>
			<a href="<?php echo esc_url( \DGL\Dashboard\Router::url( 'join' ) ); ?>"><?php esc_html_e( 'Join the Doing Good Leeds platform', 'dgl-platform' ); ?></a>
		</p>
	</div>
