<?php
/**
 * Turning a message into something an email client will render.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Email;

use DGL\Brand;

defined( 'ABSPATH' ) || exit;

/**
 * The HTML shell.
 *
 * Email is not the web. Outlook renders through Word, Gmail strips `<style>`
 * blocks on forwarded mail, and every client disagrees about margins. So this
 * is tables and inline styles on purpose, not from habit: it is the only
 * approach that renders the same in all of them.
 *
 * The rules being followed, so nobody "tidies" them away later:
 *
 * - Tables for layout. Divs and flexbox collapse in Outlook.
 * - Every style inline. Gmail drops `<style>` when a message is forwarded.
 * - 600px maximum, which is the width every client agrees on.
 * - No web fonts. Montserrat is named first and falls back to the system
 *   stack, because most clients will not load the font and a missing font
 *   should degrade to Arial rather than to Times.
 * - No background images, no SVG, no external CSS.
 * - The button is a padded table cell with a link in it, not a styled anchor,
 *   because Outlook ignores padding on inline elements.
 *
 * Colours come from {@see Brand} rather than being typed in here, so the email
 * and the dashboard cannot drift apart. The hexes are used directly rather than
 * the CSS custom properties the dashboard uses: email has no theme context and
 * `var()` is not supported.
 */
final class Template {

	/** The width every email client agrees on. */
	private const WIDTH = 600;

	/**
	 * Named colours, resolved once from the brand palette.
	 *
	 * @return array<string, string>
	 */
	private static function colours(): array {
		$palette = Brand::palette();
		$roles   = Brand::roles();

		return [
			'primary' => $palette[ $roles['primary'] ],
			'link'    => $palette[ $roles['link'] ],
			'ink'     => $palette[ $roles['ink'] ],
			'page'    => $palette[ $roles['page'] ],
			'surface' => $palette[ $roles['surface'] ],
			'rule'    => $palette[ $roles['decorative'] ],
			'muted'   => '#5a6a6a',
			'hairline' => '#dfe3ec',
			'white'   => '#ffffff',
		];
	}

	private const FONT = "Montserrat, 'Helvetica Neue', Helvetica, Arial, sans-serif";

	/**
	 * Render a message as a full HTML document.
	 *
	 * @param string|null $logo_url Absolute URL of a raster logo, or null. Never
	 *                              an SVG: {@see \DGL\Logo::email_url()} enforces
	 *                              that, because Gmail drops SVG and the header
	 *                              would render empty.
	 */
	public static function render( Message $message, ?string $logo_url = null ): string {
		$c = self::colours();

		$out  = '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' . "\n";
		$out .= '<html xmlns="http://www.w3.org/1999/xhtml" lang="en-GB"><head>';
		$out .= '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />';
		$out .= '<meta name="viewport" content="width=device-width, initial-scale=1" />';
		$out .= '<meta name="color-scheme" content="light" />';
		$out .= '<meta name="supported-color-schemes" content="light" />';
		$out .= '<title>' . esc_html( $message->subject ) . '</title>';
		$out .= '</head>';
		$out .= '<body style="margin:0;padding:0;background-color:' . $c['page'] . ';">';

		$out .= self::preheader( $message->preheader );

		$out .= '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:' . $c['page'] . ';">';
		$out .= '<tr><td align="center" style="padding:24px 12px;">';
		$out .= '<table role="presentation" width="' . self::WIDTH . '" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:' . self::WIDTH . 'px;background-color:' . $c['white'] . ';border-radius:12px;overflow:hidden;">';

		$out .= self::header( $logo_url, $c );
		$out .= self::body( $message, $c );
		$out .= self::footer( $message, $c );

		$out .= '</table>';
		$out .= '</td></tr></table>';
		$out .= '</body></html>';

		return $out;
	}

	/**
	 * The grey line inboxes show after the subject.
	 *
	 * Without one, the client picks the first text it finds, which is whatever
	 * the header happens to contain. The run of non-breaking spaces afterwards
	 * stops it pulling the opening sentence in as well.
	 */
	private static function preheader( string $text ): string {
		if ( '' === trim( $text ) ) {
			return '';
		}

		return '<div style="display:none;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;mso-hide:all;">'
			. esc_html( $text )
			. str_repeat( '&#847;&zwnj;&nbsp;', 30 )
			. '</div>';
	}

	/**
	 * @param array<string, string> $c
	 */
	private static function header( ?string $logo_url, array $c ): string {
		/*
		 * The band is 88px tall either way. At 40px the round DGLP mark was a
		 * badge with unreadable words in it; at 64px the words read, and the
		 * padding gives back the difference so the header takes no more room.
		 */
		$out = '<tr><td style="background-color:' . $c['primary'] . ';padding:12px 32px;">';

		if ( is_string( $logo_url ) && '' !== $logo_url ) {
			/*
			 * Height is set in the style as well as the attribute because
			 * Outlook reads the attribute and everything else reads the style.
			 * Width is left to the image so a landscape lockup is not squashed.
			 */
			$out .= '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '"'
				. ' height="64" style="height:64px;width:auto;display:block;border:0;outline:none;text-decoration:none;" />';
		} else {
			$out .= '<span style="font-family:' . self::FONT . ';font-size:20px;font-weight:700;color:' . $c['white'] . ';">'
				. esc_html( get_bloginfo( 'name' ) ) . '</span>';
		}

		return $out . '</td></tr>';
	}

	/**
	 * @param array<string, string> $c
	 */
	private static function body( Message $message, array $c ): string {
		$out = '<tr><td style="padding:32px;font-family:' . self::FONT . ';font-size:16px;line-height:1.6;color:' . $c['ink'] . ';">';

		if ( '' !== $message->heading ) {
			$out .= '<h1 style="margin:0 0 16px;font-family:' . self::FONT . ';font-size:24px;line-height:1.3;font-weight:700;color:' . $c['primary'] . ';">'
				. esc_html( $message->heading ) . '</h1>';
		}

		foreach ( $message->paragraphs as $paragraph ) {
			$out .= '<p style="margin:0 0 16px;">' . esc_html( $paragraph ) . '</p>';
		}

		$out .= self::items( $message, $c );
		$out .= self::facts( $message, $c );
		$out .= self::note( $message, $c );
		$out .= self::button( $message, $c );

		return $out . '</td></tr>';
	}

	/**
	 * The list in a digest.
	 *
	 * A table of rows rather than a <ul>, because Outlook renders through Word
	 * and Word's list handling is its own field of study. Each row is a linked
	 * title, a line of context and a summary; the whole row is not a link,
	 * because a link that wraps a paragraph reads as a wall of underline in
	 * clients that do not honour the styling.
	 *
	 * @param array<string, string> $c
	 */
	private static function items( Message $message, array $c ): string {
		if ( [] === $message->items ) {
			return '';
		}

		$out     = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 24px;">';
		$section = null;
		$first   = true;

		foreach ( $message->items as $item ) {
			$title   = (string) ( $item['title'] ?? '' );
			$meta    = (string) ( $item['meta'] ?? '' );
			$url     = (string) ( $item['url'] ?? '' );
			$summary = (string) ( $item['summary'] ?? '' );
			$date    = is_array( $item['date'] ?? null ) ? $item['date'] : null;
			$name    = (string) ( $item['section'] ?? '' );

			if ( '' === $title ) {
				continue;
			}

			/*
			 * A heading each time the section changes: Events, News,
			 * Training. Somebody skimming for one kind of thing finds it
			 * without reading every row.
			 */
			if ( '' !== $name && $name !== $section ) {
				$section = $name;
				$out    .= '<tr><td style="padding:' . ( $first ? '4px' : '28px' ) . ' 0 6px;font-family:' . self::FONT . ';font-size:12px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;color:' . $c['muted'] . ';border-bottom:2px solid ' . $c['primary'] . ';">'
					. esc_html( $name ) . '</td></tr>';
				$first   = false;
			}

			$out .= '<tr><td style="padding:14px 0;border-bottom:1px solid ' . $c['rule'] . ';">';
			$out .= '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%"><tr>';

			/*
			 * The calendar leaf, as on the site: month over day in a small
			 * bordered cell. Tables and inline styles only, because this is
			 * email. It is repeated in the text under the title for anyone
			 * whose client drops the styling.
			 *
			 * An event's picture sits in the same left column, under the
			 * leaf and the same width, so the text beside them keeps the rest
			 * of the row. Every other row has no leaf, so its picture goes on
			 * the right, below.
			 */
			$under = null !== $date ? self::picture( $item, \DGL\Email\Digest\Thumb::SHOWN_UNDER_DATE, $c ) : '';

			if ( null !== $date ) {
				$leaf = \DGL\Email\Digest\Thumb::SHOWN_UNDER_DATE;
				$out .= '<td width="' . ( $leaf + 2 ) . '" valign="top" style="padding:0 14px 0 0;">'
					. '<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="' . $leaf . '" style="border:1px solid ' . $c['rule'] . ';border-radius:10px;background:' . $c['white'] . ';">'
					. '<tr><td align="center" style="padding:7px 2px 2px;font-family:' . self::FONT . ';font-size:11px;font-weight:700;letter-spacing:0.06em;text-transform:uppercase;line-height:1;color:' . $c['link'] . ';">' . esc_html( (string) $date['month'] ) . '</td></tr>'
					. '<tr><td align="center" style="padding:0 2px 7px;font-family:' . self::FONT . ';font-size:22px;font-weight:700;line-height:1;color:' . $c['ink'] . ';">' . esc_html( (string) $date['day'] ) . '</td></tr>'
					. '</table>'
					. ( '' !== $under ? '<div style="margin:8px 0 0;">' . $under . '</div>' : '' )
					. '</td>';
			}

			$out .= '<td valign="top">';

			$heading = '<span style="font-family:' . self::FONT . ';font-size:17px;font-weight:700;line-height:1.35;color:' . $c['primary'] . ';">'
				. esc_html( $title ) . '</span>';

			$out .= '' !== $url
				? '<a href="' . esc_url( $url ) . '" style="text-decoration:none;color:' . $c['primary'] . ';">' . $heading . '</a>'
				: $heading;

			if ( '' !== $meta ) {
				$out .= '<div style="margin:4px 0 0;font-family:' . self::FONT . ';font-size:13px;color:' . $c['muted'] . ';">'
					. esc_html( $meta ) . '</div>';
			}

			if ( '' !== $summary ) {
				$out .= '<div style="margin:8px 0 0;font-family:' . self::FONT . ';font-size:15px;line-height:1.55;color:' . $c['ink'] . ';">'
					. esc_html( $summary ) . '</div>';
			}

			$out .= '</td>';

			// No leaf, so no column to share: the picture goes on the right.
			$beside = null === $date ? self::picture( $item, \DGL\Email\Digest\Thumb::SHOWN, $c ) : '';

			if ( '' !== $beside ) {
				$out .= '<td width="' . ( \DGL\Email\Digest\Thumb::SHOWN + 16 ) . '" valign="top" align="right" style="padding:0 0 0 16px;">' . $beside . '</td>';
			}

			$out .= '</tr></table></td></tr>';
		}

		return $out . '</table>';
	}

	/**
	 * An item's picture as a linked square, or '' when it has none.
	 *
	 * Fixed width and height as attributes as well as in the style, because
	 * Outlook reads only the attributes. The alt text is what a client that
	 * blocks images shows in its place. The box is tinted with the pale surface
	 * colour, not the rule colour: a client that blocks images shows the tint,
	 * and a strong colour there looks like a designed block, not a missing
	 * picture. The address has to be http or https:
	 * anything else is dropped rather than put in a src.
	 *
	 * @param array<string, mixed>  $item
	 * @param array<string, string> $c
	 */
	private static function picture( array $item, int $size, array $c ): string {
		$image = $item['image'] ?? null;
		$src   = is_array( $image ) ? esc_url( (string) ( $image['url'] ?? '' ) ) : '';

		if ( '' === $src ) {
			return '';
		}

		$url = (string) ( $item['url'] ?? '' );
		$pic = '<img src="' . $src . '" width="' . $size . '" height="' . $size . '" alt="' . esc_attr( (string) ( $image['alt'] ?? '' ) ) . '"'
			. ' style="display:block;width:' . $size . 'px;height:' . $size . 'px;border:0;border-radius:8px;background:' . $c['surface'] . ';">';

		return '' !== $url ? '<a href="' . esc_url( $url ) . '" style="text-decoration:none;">' . $pic . '</a>' : $pic;
	}

	/**
	 * @param array<string, string> $c
	 */
	private static function facts( Message $message, array $c ): string {
		if ( [] === $message->facts ) {
			return '';
		}

		$out = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"'
			. ' style="margin:0 0 24px;background-color:' . $c['surface'] . ';border-radius:8px;">';

		foreach ( $message->facts as $label => $value ) {
			$out .= '<tr>';
			$out .= '<td style="padding:10px 16px;font-family:' . self::FONT . ';font-size:14px;color:' . $c['muted'] . ';white-space:nowrap;vertical-align:top;">'
				. esc_html( (string) $label ) . '</td>';
			$out .= '<td style="padding:10px 16px;font-family:' . self::FONT . ';font-size:14px;font-weight:600;color:' . $c['ink'] . ';vertical-align:top;">'
				. esc_html( $value ) . '</td>';
			$out .= '</tr>';
		}

		return $out . '</table>';
	}

	/**
	 * A moderator's message to the member.
	 *
	 * Quoted in a tinted block with a rule down the left so it reads as
	 * somebody's words rather than more system text. It is the part of the
	 * email that actually matters to the person reading it.
	 *
	 * @param array<string, string> $c
	 */
	private static function note( Message $message, array $c ): string {
		if ( ! $message->has_note() ) {
			return '';
		}

		$out = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 24px;">';
		$out .= '<tr><td style="padding:16px 20px;background-color:' . $c['surface'] . ';border-radius:8px;">';

		if ( '' !== $message->note_label ) {
			$out .= '<p style="margin:0 0 8px;font-family:' . self::FONT . ';font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:0.04em;color:' . $c['muted'] . ';">'
				. esc_html( $message->note_label ) . '</p>';
		}

		/*
		 * The note is member-facing free text written by a moderator. It is
		 * escaped and its line breaks turned into `<br />` afterwards, so a
		 * paragraph break survives but nothing in the text can become markup.
		 */
		$note = nl2br( esc_html( trim( $message->note ) ), false );

		$out .= '<p style="margin:0;font-family:' . self::FONT . ';font-size:16px;line-height:1.6;color:' . $c['ink'] . ';">' . $note . '</p>';

		return $out . '</td></tr></table>';
	}

	/**
	 * @param array<string, string> $c
	 */
	private static function button( Message $message, array $c ): string {
		if ( ! $message->has_cta() ) {
			return '';
		}

		$url = esc_url( $message->cta_url );

		$out = '<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0 0 8px;">';
		$out .= '<tr><td align="center" bgcolor="' . $c['primary'] . '" style="background-color:' . $c['primary'] . ';border-radius:8px;">';
		$out .= '<a href="' . $url . '" style="display:inline-block;padding:14px 28px;font-family:' . self::FONT . ';font-size:15px;font-weight:500;color:' . $c['white'] . ';text-decoration:none;border-radius:8px;">'
			. esc_html( $message->cta_label ) . '</a>';
		$out .= '</td></tr></table>';

		/*
		 * The same link in plain text underneath. Some corporate clients strip
		 * the button entirely, and a member who cannot see it still needs a way
		 * through.
		 */
		$out .= '<p style="margin:0;font-family:' . self::FONT . ';font-size:13px;line-height:1.5;color:' . $c['muted'] . ';word-break:break-all;">'
			. esc_html__( 'If the button does not work, copy this into your browser:', 'dgl-platform' ) . '<br />'
			. '<a href="' . $url . '" style="color:' . $c['link'] . ';">' . esc_html( $message->cta_url ) . '</a></p>';

		return $out;
	}

	/**
	 * @param array<string, string> $c
	 */
	private static function footer( Message $message, array $c ): string {
		if ( [] === $message->footnotes ) {
			return '';
		}

		/*
		 * Small print, not a panel: on white under a hairline, so the shaded
		 * boxes above (the facts, the note) stay the only shaded things and
		 * the footer cannot be read as more of the message.
		 */
		$out = '<tr><td style="padding:0 32px 28px;background-color:' . $c['white'] . ';">'
			. '<div style="border-top:1px solid ' . $c['hairline'] . ';padding-top:20px;">';

		foreach ( $message->footnotes as $footnote ) {
			$out .= '<p style="margin:0 0 10px;font-family:' . self::FONT . ';font-size:13px;line-height:1.55;color:' . $c['muted'] . ';">'
				. Footer::html( $footnote, $c['link'] ) . '</p>';
		}

		return $out . '</div></td></tr>';
	}

}
