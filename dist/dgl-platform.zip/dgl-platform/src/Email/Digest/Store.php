<?php
/**
 * Where digest preferences live.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Email\Digest;

use DateTimeImmutable;
use DateTimeZone;
use DGL\Org\Org;

defined( 'ABSPATH' ) || exit;

/**
 * The digest subscription table, and the only code that reads or writes it.
 *
 * It holds preferences and nothing else. The address and the organisation are
 * read from the account at send time rather than copied in here, because both
 * change and a copy that drifts means posting somebody's digest to an address
 * they have already left, or filtering their own organisation's items out by an
 * organisation they are no longer in.
 *
 * A row existing is not consent. `consent_at` is, and {@see Subscription}
 * refuses to send without it.
 */
final class Store {

	/** '1' when somebody ticked the round-up box at registration, '0' when they did not. Absent: they joined before the box existed. */
	public const OPTIN_META = 'dgl_digest_optin';

	/** When they ticked it, UTC `Y-m-d H:i:s`. */
	public const OPTIN_AT_META = 'dgl_digest_optin_at';

	/**
	 * Keep what somebody chose at registration, so approval honours it later.
	 */
	public static function record_choice( int $user_id, bool $wants ): void {
		if ( $user_id <= 0 ) {
			return;
		}

		update_user_meta( $user_id, self::OPTIN_META, $wants ? '1' : '0' );

		if ( $wants ) {
			update_user_meta( $user_id, self::OPTIN_AT_META, self::now() );
		}
	}

	/**
	 * Whether somebody said no at registration. Nothing recorded is not a no:
	 * accounts made before the box existed were told the round-up came with
	 * approval, and keep it.
	 */
	public static function declined_at_registration( int $user_id ): bool {
		return '0' === (string) get_user_meta( $user_id, self::OPTIN_META, true );
	}

	public static function name(): string {
		global $wpdb;

		return $wpdb->prefix . 'dgl_digest_subs';
	}

	/**
	 * Formatted the way `dbDelta()` demands.
	 *
	 * Keyed on the user: one person, one set of preferences. `due` is the
	 * index the runner sweeps, and it is deliberately (frequency, last_sent_at)
	 * so a daily run does not read a monthly subscriber's row at all.
	 */
	public static function schema(): string {
		global $wpdb;

		$table   = self::name();
		$collate = $wpdb->get_charset_collate();

		return "CREATE TABLE {$table} (
	user_id bigint(20) unsigned NOT NULL,
	types text NOT NULL,
	topic_ids text NOT NULL,
	frequency varchar(20) NOT NULL default 'weekly',
	include_own_org tinyint(1) unsigned NOT NULL default 0,
	unsubscribe_token char(48) NOT NULL default '',
	consent_at datetime default NULL,
	consent_source varchar(40) NOT NULL default '',
	last_sent_at datetime default NULL,
	updated_at datetime NOT NULL default '1970-01-01 00:00:00',
	PRIMARY KEY  (user_id),
	UNIQUE KEY unsub (unsubscribe_token),
	KEY due (frequency,last_sent_at)
) {$collate};";
	}

	public static function create(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( self::schema() );
	}

	public static function exists(): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name cannot be parameterised.
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::name() ) );
	}

	/* ---------------------------------------------------------------------
	 * Reading
	 * ------------------------------------------------------------------ */

	/**
	 * One person's preferences, or null if they have never set any.
	 *
	 * Null is not the same as unsubscribed. Somebody who has never been asked
	 * has no preferences, and the difference matters: the first is a question
	 * to put to them, the second is an answer to respect.
	 */
	public static function for_user( int $user_id ): ?Subscription {
		global $wpdb;

		$table = self::name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d", $user_id ), ARRAY_A );

		return is_array( $row ) ? self::hydrate( $row ) : null;
	}

	public static function for_token( string $token ): ?Subscription {
		global $wpdb;

		$token = trim( $token );

		if ( '' === $token ) {
			return null;
		}

		$table = self::name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE unsubscribe_token = %s", $token ), ARRAY_A );

		return is_array( $row ) ? self::hydrate( $row ) : null;
	}

	/**
	 * Subscribers whose digest is owed, for one cadence.
	 *
	 * Due-ness is decided by {@see Frequency}, which is pure and tested, rather
	 * than in SQL. The query narrows to one cadence so the runner is not
	 * hydrating every subscriber on the site to discard most of them.
	 *
	 * @return Subscription[]
	 */
	public static function due( string $frequency, DateTimeImmutable $now, int $limit = 500 ): array {
		global $wpdb;

		$table = self::name();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table}
				WHERE frequency = %s AND consent_at IS NOT NULL
				ORDER BY last_sent_at IS NULL DESC, last_sent_at ASC
				LIMIT %d",
				$frequency,
				max( 1, $limit )
			),
			ARRAY_A
		);

		$due = [];

		foreach ( is_array( $rows ) ? $rows : [] as $row ) {
			$subscription = self::hydrate( $row );

			if ( null === $subscription ) {
				continue;
			}

			if ( Frequency::is_due( $subscription->frequency, $subscription->last_sent_at, $subscription->consent_at, $now, wp_timezone() ) ) {
				$due[] = $subscription;
			}
		}

		return $due;
	}

	/**
	 * Turn a row into a subscription, filling in what lives on the account.
	 *
	 * Returns null when the account has gone. A row whose user no longer exists
	 * is an address nobody can be responsible for.
	 *
	 * @param array<string, mixed> $row
	 */
	private static function hydrate( array $row ): ?Subscription {
		$user_id = (int) ( $row['user_id'] ?? 0 );
		$user    = $user_id > 0 ? get_userdata( $user_id ) : null;

		if ( ! $user instanceof \WP_User ) {
			return null;
		}

		$consent = (string) ( $row['consent_at'] ?? '' );

		return new Subscription(
			user_id: $user_id,
			email: (string) $user->user_email,
			types: self::decode( (string) ( $row['types'] ?? '' ) ),
			topic_ids: array_map( 'intval', self::decode( (string) ( $row['topic_ids'] ?? '' ) ) ),
			frequency: (string) ( $row['frequency'] ?? Frequency::WEEKLY ),
			last_sent_at: self::nullable( $row['last_sent_at'] ?? null ),
			unsubscribe_token: (string) ( $row['unsubscribe_token'] ?? '' ),
			consent_at: '' !== $consent && ! str_starts_with( $consent, '0000-00-00' ) ? $consent : null,
			org_id: (int) ( Org::for_user( $user_id ) ?? 0 ),
			include_own_org: (bool) ( $row['include_own_org'] ?? false ),
		);
	}

	/* ---------------------------------------------------------------------
	 * Writing
	 * ------------------------------------------------------------------ */

	/**
	 * Save somebody's preferences.
	 *
	 * Consent is stamped the first time they ask for something and cleared the
	 * moment they ask for nothing. Under PECR the record has to say when they
	 * agreed and how, so both are written, and neither is inferred later from
	 * the row existing.
	 *
	 * @param string[] $types
	 * @param int[]    $topic_ids
	 */
	public static function save(
		int $user_id,
		array $types,
		array $topic_ids,
		string $frequency,
		bool $include_own_org,
		string $consent_source = 'dashboard'
	): bool {
		global $wpdb;

		if ( $user_id <= 0 ) {
			return false;
		}

		$existing = self::for_user( $user_id );
		$wants    = [] !== $types;

		if ( $wants ) {
			// Keep the original timestamp. Re-recording consent every time
			// somebody changes a checkbox would erase the date they actually
			// agreed, which is the only part of the record that matters.
			$consent = $existing?->consent_at ?? self::now();
			$source  = $existing?->has_consent() ? '' : $consent_source;
		} else {
			$consent = null;
			$source  = '';
		}

		$data = [
			'types'             => self::encode( array_values( $types ) ),
			'topic_ids'         => self::encode( array_map( 'strval', $topic_ids ) ),
			'frequency'         => Frequency::is_valid( $frequency ) ? $frequency : Frequency::WEEKLY,
			'include_own_org'   => $include_own_org ? 1 : 0,
			'unsubscribe_token' => '' !== (string) ( $existing?->unsubscribe_token ?? '' ) ? $existing->unsubscribe_token : self::new_token(),
			'consent_at'        => $consent,
			'updated_at'        => self::now(),
		];

		if ( '' !== $source ) {
			$data['consent_source'] = $source;
		}

		if ( null === $existing ) {
			$data['user_id'] = $user_id;

			return false !== $wpdb->insert( self::name(), $data );
		}

		return false !== $wpdb->update( self::name(), $data, [ 'user_id' => $user_id ] );
	}

	/**
	 * The default subscription an approved member starts with: everything the
	 * site offers, every topic, once a week, their own organisation's posts
	 * left out because they have seen those. Only for somebody with no row at
	 * all: an unsubscribe is a record, and a later approval never undoes it.
	 *
	 * @param string $source How they came to be subscribed, for the consent record.
	 */
	public static function subscribe_default( int $user_id, string $source ): bool {
		if ( $user_id <= 0 || ! self::exists() || null !== self::for_user( $user_id ) ) {
			return false;
		}

		// They did not tick the box at registration: no round-up, whatever approves them later.
		if ( self::declined_at_registration( $user_id ) ) {
			return false;
		}

		// Every type the public can see. Funding held back until it is signed off
		// is not one: nobody joining before then is signed up for it unasked.
		$types = \DGL\Funding\Visibility::filter_types( array_values( \DGL\PostTypes::feed_keys() ), true );

		return [] !== $types && self::save( $user_id, $types, [], Frequency::WEEKLY, true, $source );
	}

	/**
	 * Subscribers who have agreed to digests and whose own organisation is
	 * left out of theirs. Somebody who has unsubscribed is not listed: that
	 * is their record, and nothing here should touch it.
	 *
	 * @return int[] User IDs, lowest first.
	 */
	public static function without_own_org(): array {
		global $wpdb;

		$table = self::name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- the table name is ours.
		$ids = $wpdb->get_col( "SELECT user_id FROM {$table} WHERE include_own_org = 0 AND consent_at IS NOT NULL ORDER BY user_id ASC" );

		return array_map( 'intval', (array) $ids );
	}

	/**
	 * Change only whether somebody's own organisation is in their digest.
	 * Types, topics, cadence, consent and the last send are left exactly as
	 * they were, which {@see self::save()} cannot promise: it rebuilds the row.
	 */
	public static function set_own_org( int $user_id, bool $include ): bool {
		global $wpdb;

		if ( $user_id <= 0 || null === self::for_user( $user_id ) ) {
			return false;
		}

		return false !== $wpdb->update(
			self::name(),
			[
				'include_own_org' => $include ? 1 : 0,
				'updated_at'      => self::now(),
			],
			[ 'user_id' => $user_id ]
		);
	}

	/**
	 * Remove somebody's digest row because their account has gone.
	 *
	 * Not an unsubscribe: that keeps the row, as the record that they opted
	 * out, so a later approval cannot sign them up again. Here there is nobody
	 * left to sign up, and a consent date and an unsubscribe link kept for an
	 * account that no longer exists record nothing anybody can answer for.
	 * Hooked to `deleted_user`, which WordPress fires after an administrator
	 * deletes the account.
	 */
	public static function forget( int $user_id ): bool {
		global $wpdb;

		if ( $user_id <= 0 || ! self::exists() ) {
			return false;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return false !== $wpdb->delete( self::name(), [ 'user_id' => $user_id ], [ '%d' ] );
	}

	/**
	 * Rows whose account no longer exists: left by accounts deleted before
	 * {@see self::forget()} was hooked up.
	 *
	 * @return int[] User IDs, lowest first.
	 */
	public static function orphans(): array {
		global $wpdb;

		$table = self::name();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- the table names are ours and core's.
		$ids = $wpdb->get_col( "SELECT s.user_id FROM {$table} s LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE u.ID IS NULL ORDER BY s.user_id ASC" );

		return array_map( 'intval', (array) $ids );
	}

	/**
	 * Approved member accounts that have never had a digest row.
	 *
	 * @return int[]
	 */
	public static function approved_without_row(): array {
		global $wpdb;

		$ids = get_users(
			[
				'meta_key'   => \DGL\Meta::USER_ACCOUNT_STATUS, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value' => \DGL\Access\UserContext::ACCOUNT_APPROVED, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'fields'     => 'ID',
				'number'     => -1,
			]
		);

		if ( [] === $ids ) {
			return [];
		}

		$table = self::name();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$have = array_map( 'intval', (array) $wpdb->get_col( "SELECT user_id FROM {$table}" ) );

		return array_values( array_diff( array_map( 'intval', $ids ), $have ) );
	}

	/**
	 * Stop sending, keeping the record of what they had asked for.
	 *
	 * Consent is cleared rather than the row deleted. Deleting it would lose
	 * the fact that this person opted out, and the next import or bulk change
	 * would happily start writing to them again.
	 */
	public static function unsubscribe( int $user_id ): bool {
		global $wpdb;

		return false !== $wpdb->update(
			self::name(),
			[
				'types'      => self::encode( [] ),
				'consent_at' => null,
				'updated_at' => self::now(),
			],
			[ 'user_id' => $user_id ],
			[ '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	/**
	 * Record the slot that was handled, whether a digest went out or the
	 * period was quiet. Each digest then covers exactly one period, and a
	 * quiet week is a week with no email, not a week folded into the next.
	 */
	public static function mark_sent( int $user_id, string $at ): bool {
		global $wpdb;

		return false !== $wpdb->update(
			self::name(),
			[ 'last_sent_at' => $at ],
			[ 'user_id' => $user_id ],
			[ '%s' ],
			[ '%d' ]
		);
	}

	/* ---------------------------------------------------------------------
	 * Odds and ends
	 * ------------------------------------------------------------------ */

	/**
	 * The unsubscribe token.
	 *
	 * Stored rather than derived, so it can be looked up by a single indexed
	 * read from a link somebody clicks without being signed in. It is a
	 * low-value secret - the worst it does is stop somebody's newsletter - but
	 * it is per-subscriber and unguessable, so one person's link cannot
	 * unsubscribe another.
	 */
	public static function new_token(): string {
		return bin2hex( random_bytes( 24 ) );
	}

	/**
	 * @param string[] $values
	 */
	private static function encode( array $values ): string {
		return implode( ',', array_filter( array_map( 'strval', $values ), static fn( string $v ): bool => '' !== $v ) );
	}

	/**
	 * @return string[]
	 */
	private static function decode( string $stored ): array {
		if ( '' === trim( $stored ) ) {
			return [];
		}

		return array_values( array_filter( array_map( 'trim', explode( ',', $stored ) ), static fn( string $v ): bool => '' !== $v ) );
	}

	private static function nullable( mixed $value ): ?string {
		$value = (string) ( $value ?? '' );

		return ( '' === $value || str_starts_with( $value, '0000-00-00' ) ) ? null : $value;
	}

	public static function now(): string {
		return ( new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) ) )->format( 'Y-m-d H:i:s' );
	}
}
