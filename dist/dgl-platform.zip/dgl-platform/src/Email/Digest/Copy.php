<?php
/**
 * What a digest says.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Email\Digest;

use DGL\Email\Message;

defined( 'ABSPATH' ) || exit;

/**
 * Digest wording. Pure: takes strings, returns a {@see Message}.
 *
 * Held apart from {@see \DGL\Email\Copy} for the same reason the invitation
 * wording is. That class answers to the workflow's message keys and the suite
 * asserts the two sets line up; a digest is not a transition.
 */
final class Copy {

	public const KEY = 'digest';

	public const AUDIENCE = 'subscriber';

	/**
	 * The digest itself.
	 *
	 * The subject leads with the count, because the decision to open is made in
	 * a list of subject lines and "5 new things" answers the only question
	 * being asked there. The unsubscribe link is a footnote on every send,
	 * never buried and never conditional.
	 *
	 * @param array<int, array{title:string, meta:string, url:string, summary:string}> $items
	 */
	public static function digest(
		array $items,
		string $frequency,
		string $site_name,
		string $unsubscribe_url,
		string $preferences_url,
		string $browse_url = '',
		bool $filtered = false
	): Message {
		$count = count( $items );
		$site  = '' !== trim( $site_name ) ? $site_name : __( 'the partnership', 'dgl-platform' );

		$period = match ( $frequency ) {
			Frequency::DAILY   => __( 'daily', 'dgl-platform' ),
			Frequency::MONTHLY => __( 'monthly', 'dgl-platform' ),
			default            => __( 'weekly', 'dgl-platform' ),
		};

		$subject = sprintf(
			/* translators: 1: daily, weekly or monthly, 2: number of items. */
			_n( 'Your %1$s round-up: %2$d new thing added', 'Your %1$s round-up: %2$d new things added', $count, 'dgl-platform' ),
			$period,
			$count
		);

		$cadence = match ( $frequency ) {
			Frequency::DAILY   => __( 'You get this every morning.', 'dgl-platform' ),
			Frequency::MONTHLY => __( 'You get this on the first of the month.', 'dgl-platform' ),
			default            => __( 'You get this on Tuesday mornings.', 'dgl-platform' ),
		};

		return new Message(
			key: self::KEY,
			audience: self::AUDIENCE,
			subject: $subject,
			preheader: self::preheader( $items ),
			heading: match ( $frequency ) {
				Frequency::DAILY   => __( 'Your daily round-up', 'dgl-platform' ),
				Frequency::MONTHLY => __( 'Your monthly round-up', 'dgl-platform' ),
				default            => __( 'Your weekly round-up', 'dgl-platform' ),
			},
			paragraphs: [ self::intro( $frequency, $filtered ) ],
			cta_label: '' !== $browse_url ? __( 'See everything', 'dgl-platform' ) : '',
			cta_url: $browse_url,
			footnotes: [
				\DGL\Email\Footer::sent_because(
					sprintf(
						/* translators: %s: site name. */
						__( 'you have an account on %s.', 'dgl-platform' ),
						$site
					)
				),
				sprintf(
					/* translators: 1: how often, e.g. "You get this on Tuesday mornings.", 2: "Change what you get", linked, 3: "stop these emails", linked. */
					__( '%1$s %2$s or %3$s.', 'dgl-platform' ),
					$cadence,
					\DGL\Email\Footer::link( __( 'Change what you get', 'dgl-platform' ), $preferences_url ),
					\DGL\Email\Footer::link( __( 'stop these emails', 'dgl-platform' ), $unsubscribe_url )
				),
				\DGL\Email\Footer::questions(),
			],
			items: $items
		);
	}

	/**
	 * The line under the heading.
	 *
	 * It says what the digest holds: what has been added in the period, not
	 * what is coming up. When the subscriber has chosen topics or kinds of
	 * item it says so, because a list that has been narrowed should not read as
	 * everything that was added.
	 */
	public static function intro( string $frequency, bool $filtered ): string {
		$line = match ( $frequency ) {
			Frequency::DAILY   => __( "Here is what's been added to the DGL Platform in the last day", 'dgl-platform' ),
			Frequency::MONTHLY => __( "Here is what's been added to the DGL Platform in the last month", 'dgl-platform' ),
			default            => __( "Here is what's been added to the DGL Platform in the last week", 'dgl-platform' ),
		};

		return $line . ( $filtered ? __( ' that matches your choices.', 'dgl-platform' ) : '.' );
	}

	/**
	 * The grey line inboxes show after the subject.
	 *
	 * The first two titles, because that is what makes somebody open it. A
	 * generic line here wastes the only other piece of text an inbox shows.
	 *
	 * @param array<int, array{title:string, meta:string, url:string, summary:string}> $items
	 */
	private static function preheader( array $items ): string {
		$titles = [];

		foreach ( array_slice( $items, 0, 2 ) as $item ) {
			$title = trim( (string) ( $item['title'] ?? '' ) );

			if ( '' !== $title ) {
				$titles[] = $title;
			}
		}

		if ( [] === $titles ) {
			return '';
		}

		$line = implode( ', ', $titles );

		if ( count( $items ) > count( $titles ) ) {
			$line .= sprintf(
				/* translators: %d: how many more items there are. */
				_n( ' and %d more', ' and %d more', count( $items ) - count( $titles ), 'dgl-platform' ),
				count( $items ) - count( $titles )
			);
		}

		return $line;
	}

	/**
	 * Confirmation that somebody has been taken off the list.
	 *
	 * Sent nowhere: this is the wording for the screen, not an email. Emailing
	 * somebody who just asked to stop being emailed is the one thing they have
	 * explicitly said they do not want.
	 */
	public static function unsubscribed_message(): string {
		return __( 'Done. You will not get any more digests. Your account and your submissions are untouched.', 'dgl-platform' );
	}
}
