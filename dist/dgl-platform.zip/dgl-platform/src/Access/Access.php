<?php
/**
 * The WordPress adapter for the access policy.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Access;

use DGL\Meta;
use DGL\Org\Org;
use DGL\PostTypes;
use DGL\Roles;
use WP_Post;

defined( 'ABSPATH' ) || exit;

/**
 * Turns WordPress users and posts into the plain contexts {@see Policy} reads,
 * and wires the policy into WordPress's own capability system so both routes
 * reach the same decision.
 *
 * Controllers should call {@see self::current_user_can()}. Nothing in the
 * plugin should ever compare organisation IDs by hand.
 */
final class Access {

	/** @var array<int, UserContext> Per-request cache. */
	private static array $user_cache = [];

	/**
	 * Meta capability => policy action.
	 *
	 * Core's `map_meta_cap()` resolves a post type's own capability names
	 * internally and then fires the filter with the ORIGINAL request, so what
	 * arrives here is `edit_post`, never `edit_dgl_item`. Both spellings are
	 * mapped: the core ones because they are what WordPress actually asks, and
	 * the post-type ones so a direct `current_user_can( 'edit_dgl_item', $id )`
	 * reaches the same decision rather than quietly bypassing it.
	 */
	private const META_CAP_MAP = [
		'edit_post'       => Policy::EDIT_ITEM,
		'delete_post'     => Policy::DELETE_ITEM,
		'read_post'       => Policy::VIEW_ITEM,
		'edit_dgl_item'   => Policy::EDIT_ITEM,
		'delete_dgl_item' => Policy::DELETE_ITEM,
		'read_dgl_item'   => Policy::VIEW_ITEM,
	];

	/**
	 * Hook the policy into WordPress capabilities.
	 */
	public static function init(): void {
		add_filter( 'map_meta_cap', [ self::class, 'map_meta_cap' ], 10, 4 );

		add_filter( 'rest_pre_dispatch', [ self::class, 'refuse_rest_route' ], 10, 3 );
		add_filter( 'rest_post_search_query', [ self::class, 'rest_search_without_items' ] );
		add_filter( 'rest_user_query', [ self::class, 'rest_users_without_items' ] );

		// Per type, once the types exist; reading them any earlier loads translations too soon.
		add_action(
			'rest_api_init',
			static function (): void {
				foreach ( \DGL\PostTypes::reviewable() as $post_type ) {
					add_filter( 'rest_pre_insert_' . $post_type, [ self::class, 'refuse_rest_insert' ] );
				}
			}
		);
	}

	/**
	 * Can this user perform this action, optionally on this item?
	 *
	 * @param int                 $user_id The actor.
	 * @param string              $action  A {@see Policy} constant.
	 * @param int|WP_Post|null    $object  The target item, if the action needs one.
	 */
	public static function can( int $user_id, string $action, int|WP_Post|null $object = null ): bool {
		return Policy::decide(
			self::user_context( $user_id ),
			$action,
			null === $object ? null : self::item_context( $object )
		);
	}

	/**
	 * The same question for whoever is logged in.
	 */
	public static function current_user_can( string $action, int|WP_Post|null $object = null ): bool {
		return self::can( get_current_user_id(), $action, $object );
	}

	/** Drop a cached snapshot after something about the person changed. */
	public static function forget( int $user_id ): void {
		unset( self::$user_cache[ $user_id ] );
	}

	/**
	 * Build the actor snapshot. Cached for the request.
	 */
	public static function user_context( int $user_id ): UserContext {
		if ( isset( self::$user_cache[ $user_id ] ) ) {
			return self::$user_cache[ $user_id ];
		}

		if ( $user_id <= 0 ) {
			return self::$user_cache[ $user_id ] = UserContext::anonymous();
		}

		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return self::$user_cache[ $user_id ] = UserContext::anonymous();
		}

		$org_id = Org::for_user( $user_id );
		$status = (string) get_user_meta( $user_id, Meta::USER_ACCOUNT_STATUS, true );

		/*
		 * Staff accounts are not members and have no account approval of their
		 * own to clear, so they default to approved rather than pending.
		 */
		if ( '' === $status ) {
			$is_staff = array_intersect(
				[ Roles::MODERATOR, UserContext::ROLE_ADMIN ],
				(array) $user->roles
			);

			$status = $is_staff ? UserContext::ACCOUNT_APPROVED : UserContext::ACCOUNT_PENDING;
		}

		return self::$user_cache[ $user_id ] = new UserContext(
			user_id: $user_id,
			roles: array_values( (array) $user->roles ),
			org_id: $org_id,
			org_role: Org::role_for_user( $user_id ),
			account_status: $status,
			org_approved: Org::is_approved( $org_id ),
		);
	}

	/**
	 * Build the item snapshot from the post, which is the source of truth. The
	 * index table is a cache and is deliberately not trusted for permissions.
	 */
	public static function item_context( int|WP_Post $post ): ?ItemContext {
		$post = get_post( $post );

		if ( ! $post instanceof WP_Post ) {
			return null;
		}

		if ( ! PostTypes::is_submittable( $post->post_type ) && PostTypes::REVISION !== $post->post_type ) {
			return null;
		}

		/*
		 * A pending edit inherits its parent's organisation. Permission to touch
		 * the revision is permission to touch the thing it would replace.
		 */
		$org_source = PostTypes::REVISION === $post->post_type && $post->post_parent > 0
			? (int) $post->post_parent
			: (int) $post->ID;

		return new ItemContext(
			post_id: (int) $post->ID,
			post_type: (string) $post->post_type,
			org_id: Org::for_item( $org_source ),
			author_id: (int) $post->post_author,
			status: (string) $post->post_status,
		);
	}

	/**
	 * Route WordPress's meta capabilities through the policy.
	 *
	 * Two things happen here. Denials become `do_not_allow`, which nothing can
	 * override. Approvals collapse to the single primitive `edit_dgl_items`
	 * rather than WordPress's author-based mapping, because on this site the
	 * organisation owns the content, not the individual who typed it. A
	 * colleague must be able to edit a teammate's submission.
	 *
	 * @param string[] $caps    Primitive capabilities required.
	 * @param string   $cap     The capability being checked.
	 * @param int      $user_id The user being checked.
	 * @param mixed[]  $args    Context, `$args[0]` being the post ID.
	 * @return string[]
	 */
	public static function map_meta_cap( array $caps, string $cap, int $user_id, array $args ): array {
		$action = self::META_CAP_MAP[ $cap ] ?? null;

		if ( null === $action ) {
			// Deciding a submission also runs through the policy when scoped to an item.
			if ( Roles::CAP_MODERATE === $cap && isset( $args[0] ) ) {
				return self::can( $user_id, Policy::MODERATE_ITEM, (int) $args[0] )
					? [ Roles::CAP_MODERATE ]
					: [ 'do_not_allow' ];
			}

			return $caps;
		}

		if ( ! isset( $args[0] ) ) {
			return [ 'do_not_allow' ];
		}

		$context = self::item_context( (int) $args[0] );

		// Not one of ours. Leave WordPress's own mapping alone.
		if ( null === $context ) {
			return $caps;
		}

		/*
		 * WordPress's own routes (the REST API, XML-RPC, async-upload with a
		 * post) write straight to the post, past review: a live listing
		 * edited through /wp-json/wp/v2/ changes on the site at once. The
		 * member area never asks WordPress for these capabilities; it checks
		 * the policy and makes a pending edit. So through WordPress only an
		 * administrator, the one role with wp-admin, may edit or delete an
		 * item. Reading is unchanged.
		 */
		if ( Policy::VIEW_ITEM !== $action && ! self::user_context( $user_id )->is_admin() ) {
			return [ 'do_not_allow' ];
		}

		if ( ! self::can( $user_id, $action, (int) $args[0] ) ) {
			return [ 'do_not_allow' ];
		}

		return Policy::VIEW_ITEM === $action ? [ 'read' ] : [ 'edit_dgl_items' ];
	}

	/**
	 * Our items' REST routes are for administrators only, the one role with wp-admin.
	 *
	 * Nothing public reads them: listings, the finder and the map render on
	 * the server. Open, they served what the site deliberately does not show
	 * (a hidden venue, which its own page 404s) and named who wrote what.
	 * Anybody else is told the route does not exist.
	 *
	 * @param mixed            $result  A response already decided, or null.
	 * @param \WP_REST_Server  $server  The server.
	 * @param \WP_REST_Request $request The request.
	 * @return mixed
	 */
	public static function refuse_rest_route( $result, $server, $request ) {
		if ( null !== $result || ! $request instanceof \WP_REST_Request ) {
			return $result;
		}

		// WordPress matches routes ignoring case, so this must too.
		$route = strtolower( '/' . ltrim( (string) $request->get_route(), '/' ) );

		foreach ( self::rest_bases() as $base ) {
			$base = strtolower( $base );

			if ( $route === '/wp/v2/' . $base || str_starts_with( $route, '/wp/v2/' . $base . '/' ) ) {
				if ( self::user_context( get_current_user_id() )->is_admin() ) {
					return $result;
				}

				return new \WP_Error( 'rest_no_route', __( 'No route was found matching the URL and request method.', 'dgl-platform' ), [ 'status' => 404 ] );
			}
		}

		return $result;
	}

	/**
	 * The REST search, for anybody but an administrator, leaves our items out: it
	 * listed what the item routes no longer do, hidden venues included.
	 *
	 * @param array<string, mixed> $args
	 * @return array<string, mixed>
	 */
	public static function rest_search_without_items( array $args ): array {
		if ( self::user_context( get_current_user_id() )->is_admin() ) {
			return $args;
		}

		$types = (array) ( $args['post_type'] ?? [] );
		$kept  = array_values( array_diff( $types, \DGL\PostTypes::reviewable() ) );

		// Nothing left to search is no results, not every type.
		$args['post_type'] = [] === $kept ? [ 'dgl_none' ] : $kept;

		return $args;
	}

	/**
	 * The REST user list, for anybody but an administrator, does not count our items
	 * as published posts, so it never names who wrote a listing.
	 *
	 * @param array<string, mixed> $args
	 * @return array<string, mixed>
	 */
	public static function rest_users_without_items( array $args ): array {
		if ( empty( $args['has_published_posts'] ) || self::user_context( get_current_user_id() )->is_admin() ) {
			return $args;
		}

		$types = true === $args['has_published_posts'] ? get_post_types( [ 'show_in_rest' => true ] ) : (array) $args['has_published_posts'];
		$kept  = array_values( array_diff( array_values( $types ), \DGL\PostTypes::reviewable() ) );

		$args['has_published_posts'] = [] === $kept ? [ 'dgl_none' ] : $kept;

		return $args;
	}

	/**
	 * The REST base of every type in the workflow.
	 *
	 * @return string[]
	 */
	private static function rest_bases(): array {
		$bases = [];

		foreach ( \DGL\PostTypes::reviewable() as $post_type ) {
			$object = get_post_type_object( $post_type );

			if ( $object instanceof \WP_Post_Type && $object->show_in_rest ) {
				$bases[] = (string) ( $object->rest_base ?: $post_type );
			}
		}

		return $bases;
	}

	/**
	 * Refuse a member creating or changing an item through the REST API.
	 *
	 * Updates are already refused by {@see self::map_meta_cap()}; this
	 * covers creating one, which WordPress checks against the type's create
	 * capability rather than a post. An item made that way would have no
	 * organisation and skip every check the member area makes.
	 *
	 * @param \stdClass|\WP_Error $prepared The post about to be saved.
	 * @return \stdClass|\WP_Error
	 */
	public static function refuse_rest_insert( $prepared ) {
		if ( is_wp_error( $prepared ) || self::user_context( get_current_user_id() )->is_admin() ) {
			return $prepared;
		}

		return new \WP_Error( 'dgl_use_the_member_area', __( 'Listings are added and changed in the member area.', 'dgl-platform' ), [ 'status' => 403 ] );
	}

	/**
	 * Clear the per-request cache. For tests and for long-running CLI commands
	 * that switch user.
	 */
	public static function flush_cache( ?int $user_id = null ): void {
		if ( null === $user_id ) {
			self::$user_cache = [];
			return;
		}

		unset( self::$user_cache[ $user_id ] );
	}
}
