<?php
/**
 * Template loading and output escaping for the member area.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Dashboard;

defined( 'ABSPATH' ) || exit;

/**
 * Renders a template with a data array, and nothing else.
 *
 * Templates receive `$data` and are expected to escape at the point of output.
 * There is no template engine here on purpose: a WordPress developer picking
 * this up should find plain PHP templates doing obvious things.
 *
 * A child theme can override any template by putting a file of the same name
 * under `dgl-platform/` in the theme, which is the convention WordPress plugin
 * users already expect.
 */
final class View {

	/**
	 * Render a template to a string.
	 *
	 * @param string              $template Path under templates/, without .php.
	 * @param array<string,mixed> $data     Passed to the template as $data.
	 */
	public static function render( string $template, array $data = [] ): string {
		$file = self::locate( $template );

		if ( null === $file ) {
			return '';
		}

		$level = ob_get_level();

		ob_start();

		try {
			// phpcs:ignore WordPressVIPMinimum.Files.IncludingFile.UsingVariable -- path resolved by locate().
			include $file;

			return (string) ob_get_clean();
		} catch ( \Throwable $e ) {
			/*
			 * Discard the partial output. Without this the half-rendered
			 * fragment is flushed at shutdown and the member sees an unstyled
			 * page fragment with no navigation and no indication anything went
			 * wrong, which is worse than an honest error.
			 */
			while ( ob_get_level() > $level ) {
				ob_end_clean();
			}

			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( sprintf( 'DGLP Platform: template %s failed: %s', $template, $e->getMessage() ) );

			return self::failure( $template );
		}
	}

	/**
	 * Render straight to output.
	 *
	 * @param array<string,mixed> $data
	 */
	public static function output( string $template, array $data = [] ): void {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- templates escape at point of use.
		echo self::render( $template, $data );
	}

	/**
	 * What a member sees when a template dies.
	 *
	 * Deliberately says something went wrong rather than rendering nothing. An
	 * empty region looks like an empty account, and a member whose work appears
	 * to have vanished raises a support ticket.
	 */
	private static function failure( string $template ): string {
		$notice = '<p class="dgl-empty">'
			. esc_html__( 'Something went wrong showing this. Nothing has been lost. Please try again, and tell the team if it keeps happening.', 'dgl-platform' )
			. '</p>';

		if ( current_user_can( 'manage_options' ) ) {
			$notice .= '<p class="dgl-empty"><code>' . esc_html( $template ) . '</code></p>';
		}

		return $notice;
	}

	/**
	 * Find a template, preferring a child theme override.
	 *
	 * The name is sanitised rather than trusted: a template name that reached
	 * this from a URL segment must not be able to walk out of the directory.
	 */
	private static function locate( string $template ): ?string {
		$template = trim( $template, '/' );

		if ( '' === $template || str_contains( $template, '..' ) ) {
			return null;
		}

		if ( ! preg_match( '#^[a-z0-9/_-]+$#', $template ) ) {
			return null;
		}

		$relative = 'dgl-platform/' . $template . '.php';
		$theme    = locate_template( [ $relative ] );

		if ( '' !== $theme ) {
			return $theme;
		}

		$plugin = \DGL\PLUGIN_DIR . 'templates/' . $template . '.php';

		return is_readable( $plugin ) ? $plugin : null;
	}

	/**
	 * A status chip, label and all.
	 *
	 * Colour is never the only signal: the chip always carries its text, so it
	 * still reads for someone who cannot distinguish the backgrounds.
	 */
	public static function chip( string $status ): string {
		$modifier = match ( $status ) {
			\DGL\Statuses::DRAFT    => 'draft',
			\DGL\Statuses::PENDING  => 'pending',
			\DGL\Statuses::LIVE     => 'live',
			\DGL\Statuses::CHANGES  => 'changes',
			\DGL\Statuses::EXPIRED  => 'expired',
			\DGL\Statuses::ARCHIVED => 'archived',
			\DGL\Statuses::REJECTED => 'rejected',
			default                 => 'draft',
		};

		return sprintf(
			'<span class="dgl-chip dgl-chip--%s">%s</span>',
			esc_attr( $modifier ),
			esc_html( \DGL\Statuses::label( $status ) )
		);
	}

	/**
	 * Render one field's value for reading, as opposed to editing.
	 *
	 * Shared by the review step and the submission detail screen so the two
	 * cannot drift. A member who reads their answer on review and then sees it
	 * formatted differently afterwards reasonably wonders what got saved.
	 */
	public static function field_value( \DGL\Schema\Field $field, mixed $value ): string {
		$blank = '<span class="dgl-review__blank">' . esc_html__( 'Not given', 'dgl-platform' ) . '</span>';

		return match ( $field->type ) {
			\DGL\Schema\Field::CHECKBOX => esc_html( $value ? __( 'Yes', 'dgl-platform' ) : __( 'No', 'dgl-platform' ) ),
			\DGL\Schema\Field::IMAGE    => self::image_value( $value, $blank ),
			\DGL\Schema\Field::SELECT   => '' === (string) $value
				? $blank
				: esc_html( (string) ( $field->options[ (string) $value ] ?? $value ) ),
			\DGL\Schema\Field::REPEAT   => ! is_array( $value ) || [] === $value || '' === (string) ( $value['freq'] ?? '' )
				? esc_html__( 'Does not repeat', 'dgl-platform' )
				: esc_html( self::repeat_summary( (array) $value ) ),
			\DGL\Schema\Field::CHOICES  => [] === (array) $value
				? $blank
				: esc_html( implode( ', ', array_map( static fn( $v ): string => (string) ( $field->options[ (string) $v ] ?? $v ), (array) $value ) ) ),
			\DGL\Schema\Field::DATE     => '' === (string) $value ? $blank : esc_html( self::wall_date( (string) $value ) ),
			\DGL\Schema\Field::DATETIME => '' === (string) $value ? $blank : esc_html( self::wall_date( (string) $value, true ) ),
			\DGL\Schema\Field::MONEY    => '' === (string) $value
				? $blank
				: esc_html( '£' . number_format( (float) $value, 2 ) ),
			\DGL\Schema\Field::URL      => '' === (string) $value
				? $blank
				: '<a href="' . esc_url( (string) $value ) . '" rel="nofollow noopener">' . esc_html( (string) $value ) . '</a>',
			/*
			 * The description is the one field members write markup into, and
			 * the visual editor stores it as HTML. Escaping it prints the tags
			 * on screen: a moderator reads "<p>An afternoon for" and a member
			 * reviewing their own work thinks the editor has broken it.
			 *
			 * `wp_kses_post` rather than raw output. The wizard already filters
			 * it on the way in; filtering again on the way out means content
			 * that reached the database by some other route still cannot put a
			 * script on the page.
			 */
			\DGL\Schema\Field::RICHTEXT => '' === trim( wp_strip_all_tags( (string) $value ) )
				? $blank
				: wp_kses_post( (string) $value ),
			default                      => '' === (string) $value
				? $blank
				: nl2br( esc_html( (string) $value ) ),
		};
	}

	/**
	 * An attachment as a thumbnail, or the blank marker.
	 */
	private static function image_value( mixed $value, string $blank ): string {
		$id = is_numeric( $value ) ? (int) $value : 0;

		if ( $id < 1 ) {
			return $blank;
		}

		$image = wp_get_attachment_image( $id, 'medium', false, [ 'class' => 'dgl-image-preview' ] );

		return '' !== $image ? $image : $blank;
	}

	/**
	 * A human date, in the site's timezone and UK format.
	 */
	/**
	 * A stored rule in a sentence, for the review and detail screens.
	 *
	 * @param array<string, mixed> $repeat
	 */
	public static function repeat_summary( array $repeat ): string {
		return \DGL\Events\Wording::long( $repeat, '', '', static fn( string $d ): string => self::wall_date( $d ) );
	}

	/**
	 * A stored wall-clock date or datetime, in the site's own timezone.
	 *
	 * Schema dates are typed by a member in the site's local time and stored
	 * as typed. {@see date()} is for UTC stamps and would shift these by an
	 * hour in summer.
	 */
	public static function wall_date( mixed $wall, bool $with_time = false ): string {
		if ( ! is_string( $wall ) || '' === $wall ) {
			return '';
		}

		try {
			$at = new \DateTimeImmutable( str_replace( 'T', ' ', $wall ), wp_timezone() );
		} catch ( \Exception $e ) {
			return '';
		}

		return wp_date( $with_time ? 'j M Y, H:i' : 'j M Y', $at->getTimestamp() ) ?: '';
	}

	public static function date( mixed $utc, bool $with_time = false ): string {
		// WordPress date helpers return string|false, so a false reaches here
		// whenever a post has no usable modified date.
		if ( ! is_string( $utc ) || '' === $utc ) {
			return '';
		}

		$timestamp = strtotime( $utc . ' UTC' );

		if ( false === $timestamp ) {
			return '';
		}

		return wp_date( $with_time ? 'j M Y, H:i' : 'j M Y', $timestamp ) ?: '';
	}
}
