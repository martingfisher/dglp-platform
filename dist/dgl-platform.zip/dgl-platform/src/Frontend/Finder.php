<?php
/**
 * The site search behind a magnifying glass in the header.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Frontend;

use DGL\Dashboard\View;
use WP_Term;

defined( 'ABSPATH' ) || exit;

/**
 * Two small hooks make one feature. A button with a magnifier joins the
 * end of the Main Menu for the phone drawer (it joined the Top Bar menu too
 * until DGLP asked for it to go, 19 October 2026). Pressing it opens a
 * dialog in the middle of the screen: one box, a row of kinds to search
 * (all, events, news, training, spaces to hire, organisations) and Search.
 * The dialog is the ordinary search form, so it lands on the same results
 * page as the theme's own search box.
 *
 * From 0.42.0 to 0.57.2 the theme's search box (the Blocksy Pro "Search
 * Box" element) was also dropped from the header layout as it was read,
 * because the magnifier stood in for it. Once the magnifier left the top
 * bar that left the desktop header with no search at all, and the box the
 * team placed in the new header on 26 October 2026 never showed. The box
 * is now left where the header layout puts it, and from 0.57.4 the element
 * itself is this plugin's: the magnifier disc that opens the dialog
 * ({@see own_search_item()}).
 * {@see strip()} stays for anything that still wants a layout without it.
 */
final class Finder {

	/** The header element id the theme gives its search box. */
	public const SEARCH_ELEMENT = 'search-input';

	/** The menu at the top right of the desktop header, where the box was. */
	public const TOP_BAR_MENU = 'top-bar';

	/** The menu the phone drawer shows. */
	public const MAIN_MENU = 'main-menu';

	public const DIALOG_ID = 'dgl-finder';

	/** The header element id the theme gives its search box. */
	public const SEARCH_ITEM_DIR = 'templates/blocksy/search-input';

	public static function init(): void {
		add_filter( 'blocksy:header:items-root-paths', [ self::class, 'own_search_item' ] );
		add_filter( 'wp_nav_menu_items', [ self::class, 'menu_items' ], 20, 2 );
		add_action( 'wp_footer', [ self::class, 'overlay' ] );
	}

	/**
	 * The theme's list of header element directories, with this plugin's
	 * search bar in place of the Blocksy Pro "Search Box". Same id, so the
	 * header layout and the Customizer keep working; what renders is the bar
	 * that opens the site search dialog. If the theme offers no such element
	 * (Pro off), ours is added, so the layout can still place it.
	 *
	 * @param mixed $paths Directory paths, one per element.
	 * @return mixed
	 */
	public static function own_search_item( mixed $paths ): mixed {
		return is_array( $paths ) ? self::replace_item( $paths, self::SEARCH_ELEMENT, \DGL\PLUGIN_DIR . self::SEARCH_ITEM_DIR ) : $paths;
	}

	/**
	 * Swap the directory whose name is $element for $own, or add $own when
	 * there is none. Pure.
	 *
	 * @param string[] $paths
	 * @return string[]
	 */
	public static function replace_item( array $paths, string $element, string $own ): array {
		$out   = [];
		$found = false;

		foreach ( $paths as $path ) {
			if ( is_string( $path ) && basename( rtrim( $path, '/\\' ) ) === $element ) {
				if ( ! $found ) {
					$out[] = $own;
					$found = true;
				}
				continue;
			}

			$out[] = $path;
		}

		if ( ! $found ) {
			$out[] = $own;
		}

		return $out;
	}

	/**
	 * The header layout without the theme's search box.
	 *
	 * @param mixed $placements Whatever the option holds.
	 * @return mixed
	 */
	public static function without_search_box( mixed $placements ): mixed {
		return is_array( $placements ) ? self::strip( $placements, self::SEARCH_ELEMENT ) : $placements;
	}

	/**
	 * Remove one element id from every placement's list of items, however
	 * deep. Pure. The element's own settings (an array with an 'id' key)
	 * are left where they are; only the strings that place it go.
	 *
	 * @param array<mixed> $tree
	 * @return array<mixed>
	 */
	public static function strip( array $tree, string $element ): array {
		foreach ( $tree as $key => $value ) {
			if ( ! is_array( $value ) ) {
				continue;
			}

			if ( 'items' === $key && [] === array_filter( $value, static fn( mixed $v ): bool => ! is_string( $v ) ) ) {
				$tree[ $key ] = array_values( array_filter( $value, static fn( string $id ): bool => $id !== $element ) );
				continue;
			}

			$tree[ $key ] = self::strip( $value, $element );
		}

		return $tree;
	}

	/**
	 * The kinds a visitor can narrow to, in the order the dialog shows them:
	 * everything first, then what people come for most.
	 *
	 * @return array<string, string> Key ('' for all) => label.
	 */
	public static function categories(): array {
		$order = [ 'events', 'news', 'training', 'spaces', 'organisations' ];
		$out   = [ '' => __( 'All', 'dgl-platform' ) ];

		foreach ( $order as $key ) {
			if ( isset( Search::groups()[ $key ] ) ) {
				$out[ $key ] = Search::label( $key );
			}
		}

		return $out;
	}

	/**
	 * Add the trigger to the end of the menu that carries it: the Main
	 * Menu, for the phone drawer. The Top Bar had it until 19 October 2026.
	 *
	 * @param string $items The menu's list items.
	 * @param object $args  The menu arguments, with `menu` resolved to a term.
	 */
	public static function menu_items( string $items, object $args ): string {
		$placement = self::placement( $args );

		// The desktop Top Bar no longer carries the magnifier (DGLP, 19 October 2026). The phone drawer does.
		if ( is_admin() || 'main' !== $placement ) {
			return $items;
		}

		return $items . self::item( $placement );
	}

	/**
	 * Which menu this is: 'top-bar', 'main' or '' for one we leave alone.
	 *
	 * @param object $args
	 */
	public static function placement( object $args ): string {
		$menu = $args->menu ?? null;
		$slug = $menu instanceof WP_Term ? (string) $menu->slug : '';

		if ( '' === $slug && is_scalar( $menu ) ) {
			$term = is_numeric( $menu ) ? get_term( (int) $menu, 'nav_menu' ) : get_term_by( 'slug', (string) $menu, 'nav_menu' );
			$slug = $term instanceof WP_Term ? (string) $term->slug : '';
		}

		return match ( $slug ) {
			self::TOP_BAR_MENU => 'top-bar',
			self::MAIN_MENU    => 'main',
			default            => '',
		};
	}

	/**
	 * One list item holding the button. The label is always in the markup;
	 * the stylesheet hides it beside the icon in the desktop header and
	 * shows it in the phone drawer, where an icon alone among words would
	 * read badly.
	 */
	public static function item( string $placement ): string {
		return sprintf(
			'<li class="menu-item dgl-finder-item dgl-finder-item--%1$s">%2$s</li>',
			esc_attr( $placement ),
			self::trigger()
		);
	}

	public static function trigger(): string {
		return sprintf(
			'<button type="button" class="ct-menu-link dgl-finder-trigger" data-dgl-finder-open aria-haspopup="dialog" aria-controls="%1$s" aria-expanded="false"><span class="dgl-finder-trigger__ring">%2$s</span><span class="dgl-finder-trigger__label">%3$s</span></button>',
			esc_attr( self::DIALOG_ID ),
			self::icon(),
			esc_html__( 'Search', 'dgl-platform' )
		);
	}

	/**
	 * A magnifier drawn in strokes only. The theme paints every svg in a
	 * menu with a fill, so the stylesheet turns that off again; the
	 * attribute alone was a filled disc on a stick.
	 */
	public static function icon(): string {
		return '<svg class="dgl-finder-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none"/><path d="M20 20l-4.6-4.6"/></svg>';
	}

	/** The dialog, once, at the foot of every public page. */
	public static function overlay(): void {
		if ( is_admin() ) {
			return;
		}

		View::output(
			'public/finder',
			[
				'id'         => self::DIALOG_ID,
				'action'     => home_url( '/' ),
				'categories' => self::categories(),
				'term'       => is_search() ? Search::term_from( wp_unslash( $_GET ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a public search.
				'type'       => is_search() ? Search::type_from( wp_unslash( $_GET ) ) : '', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			]
		);
	}

	/**
	 * The row of kinds, shared by the dialog and the results page.
	 *
	 * @param array<string, string> $categories
	 */
	public static function chips( array $categories, string $chosen, string $name_prefix ): string {
		$out = '';

		foreach ( $categories as $key => $label ) {
			$id   = $name_prefix . '-' . ( '' === $key ? 'all' : $key );
			$out .= sprintf(
				'<label class="dgl-finder__chip" for="%1$s"><input type="radio" name="%2$s" id="%1$s" value="%3$s"%4$s><span>%5$s</span></label>',
				esc_attr( $id ),
				esc_attr( Search::PARAM_TYPE ),
				esc_attr( $key ),
				$chosen === $key ? ' checked' : '',
				esc_html( $label )
			);
		}

		return $out;
	}
}
