<?php
/**
 * What search engines may crawl and index outside the posts WordPress knows.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Frontend;

use DGL\Dashboard\Router;
use DGL\Events\Calendar;
use DGL\Org\Directory;
use DGL\PostTypes;

defined( 'ABSPATH' ) || exit;

/**
 * Two gaps an SEO plugin cannot see.
 *
 * The member area is a set of virtual routes. Sign-in, join, invitation and
 * unsubscribe screens are public by design, and nothing marked them
 * `noindex`, so the day "Discourage search engines" is unticked they become
 * indexable. They now say noindex in the page and in a header. They are not
 * blocked in robots.txt: a crawler that may not fetch a page never sees its
 * noindex, so Google indexed the address from links anyway and Search
 * Console reported "Indexed, though blocked by robots.txt" (16 November).
 *
 * The directory, its organisation pages, the calendar and the listing pages
 * are also virtual or archive routes, which neither core's sitemap nor Rank
 * Math lists. The plugin serves its own sitemap for them at
 * /dgl-sitemap.xml and names it in robots.txt, so it works whichever SEO
 * plugin is on. Submit it once in Search Console.
 */
final class Crawl {

	public const QUERY_VAR = 'dgl_sitemap';

	public const PATH = 'dgl-sitemap.xml';

	/** The protocol's limit for one file. */
	public const MAX_URLS = 50000;

	public static function init(): void {
		add_filter( 'wp_robots', [ self::class, 'robots' ], 20 );
		add_action( 'send_headers', [ self::class, 'header' ] );

		// Rank Math prints its own robots tag, canonical, sharing tags and schema, and takes
		// core's robots tag away, so the wp_robots filter above never reaches the page.
		add_filter( 'rank_math/frontend/robots', [ self::class, 'rank_math_robots' ], 99 );
		add_filter( 'rank_math/frontend/canonical', [ self::class, 'rank_math_canonical' ], 99 );
		add_filter( 'rank_math/frontend/description', [ self::class, 'rank_math_description' ], 99 );
		add_action( 'wp_head', [ self::class, 'description_tag' ], 2 );
		add_filter( 'rank_math/json_ld', [ self::class, 'rank_math_json_ld' ], 999 );
		add_action( 'wp_head', [ self::class, 'quiet_rank_math' ], 0 );
		add_filter( 'robots_txt', [ self::class, 'robots_txt' ], 20 );
		add_action( 'init', [ self::class, 'add_rules' ] );
		add_filter( 'query_vars', [ self::class, 'add_query_var' ] );
		add_action( 'template_redirect', [ self::class, 'serve' ], 1 );
	}

	/* ---- The member area stays out ------------------------------------- */

	/** The one member-area address search engines may list: the Join page. */
	public const PUBLIC_ROUTE = 'join';

	/** What a search result says about the Join page. */
	public const JOIN_DESCRIPTION = 'Join the Doing Good Leeds platform: a free account for Leeds voluntary and community organisations to share news, events, training and opportunities.';

	/**
	 * Whether a member-area address may be indexed. Only the bare Join page,
	 * with no token and no query: a link with an invitation token or form
	 * values is one person's, not a page. Pure.
	 *
	 * @param string[] $segments The path inside the member area.
	 */
	public static function is_public_route( array $segments, bool $has_query ): bool {
		return [ self::PUBLIC_ROUTE ] === array_values( $segments ) && ! $has_query;
	}

	/** Whether this request is the indexable Join page. */
	public static function is_public_page(): bool {
		return ! is_admin() && Router::is_dashboard() && self::is_public_route( Router::segments(), [] !== $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only its presence is read.
	}

	/** Whether this request is in the member area and stays out of search. */
	private static function hidden(): bool {
		return ! is_admin() && Router::is_dashboard() && ! self::is_public_page();
	}


	/**
	 * @param array<string, mixed> $robots
	 * @return array<string, mixed>
	 */
	public static function robots( array $robots ): array {
		if ( self::hidden() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
			unset( $robots['index'], $robots['follow'], $robots['max-image-preview'] );
		}

		return $robots;
	}

	/**
	 * Rank Math's robots tag, for the member area.
	 *
	 * @param mixed $robots Rank Math's directives, keyed by name.
	 */
	public static function rank_math_robots( mixed $robots ): mixed {
		if ( self::is_public_page() ) {
			return [ 'index' => 'index', 'follow' => 'follow' ];
		}

		if ( ! self::hidden() ) {
			return $robots;
		}

		return [ 'index' => 'noindex', 'follow' => 'nofollow' ];
	}

	/** The Join page's description; Rank Math has nothing of its own for a virtual page. */
	public static function rank_math_description( mixed $description ): mixed {
		return self::is_public_page() ? self::JOIN_DESCRIPTION : $description;
	}

	/** Without Rank Math, the Join page still says what it is. */
	public static function description_tag(): void {
		if ( self::is_public_page() && ! did_action( 'rank_math/head' ) ) {
			printf( '<meta name="description" content="%s">' . "\n", esc_attr( self::JOIN_DESCRIPTION ) );
			printf( '<link rel="canonical" href="%s">' . "\n", esc_url( Router::url( self::PUBLIC_ROUTE ) ) );
		}
	}

	/** The member area has no canonical address (Rank Math guessed the news list); the Join page has its own. */
	public static function rank_math_canonical( mixed $url ): mixed {
		if ( self::is_public_page() ) {
			return Router::url( self::PUBLIC_ROUTE );
		}

		return ! is_admin() && Router::is_dashboard() ? '' : $url;
	}

	/** Nor any schema. */
	public static function rank_math_json_ld( mixed $data ): mixed {
		return ! is_admin() && Router::is_dashboard() ? [] : $data;
	}

	/** Nor sharing tags: lift Rank Math's before it prints them. */
	public static function quiet_rank_math(): void {
		if ( is_admin() || ! Router::is_dashboard() ) {
			return;
		}

		remove_all_actions( 'rank_math/opengraph/facebook' );
		remove_all_actions( 'rank_math/opengraph/twitter' );
	}

	/** The same instruction as a header, for anything that is not HTML. */
	public static function header(): void {
		if ( self::hidden() && ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow' );
		}
	}

	/**
	 * Lines to add to the virtual robots.txt: say where the sitemap is. Pure.
	 *
	 * The member area is deliberately not disallowed here. It is kept out of
	 * search by its noindex tag and header, which a crawler can only read if
	 * it is allowed to fetch the page.
	 */
	public static function robots_txt_extra( string $output, string $sitemap_url ): string {
		$line = 'Sitemap: ' . $sitemap_url;

		if ( str_contains( $output, $line ) ) {
			return $output;
		}

		/*
		 * A Sitemap line stands on its own, but a file with no group at all is
		 * read as allowing everything; keep WordPress's opening group intact.
		 */
		$group = '' === trim( $output ) ? "User-agent: *\nDisallow:\n" : '';

		return rtrim( $output ) . "\n\n" . $group . $line . "\n";
	}

	public static function robots_txt( mixed $output ): mixed {
		if ( ! is_string( $output ) || '0' === (string) get_option( 'blog_public' ) ) {
			return $output;
		}

		return self::robots_txt_extra( $output, home_url( '/' . self::PATH ) );
	}

	/* ---- The sitemap ----------------------------------------------------- */

	public static function add_rules(): void {
		add_rewrite_rule( '^' . preg_quote( self::PATH, '~' ) . '$', 'index.php?' . self::QUERY_VAR . '=1', 'top' );
	}

	/**
	 * @param string[] $vars
	 * @return string[]
	 */
	public static function add_query_var( array $vars ): array {
		$vars[] = self::QUERY_VAR;

		return $vars;
	}

	public static function serve(): void {
		global $wp, $wp_query;

		/*
		 * Rank Math's sitemap rule matches anything ending "-sitemap.xml", ours
		 * included, and is tried first, so with Rank Math on the query var is
		 * never set and the address answered 404. The address itself is
		 * enough to know the request is ours.
		 */
		$by_path = isset( $wp->request ) && self::PATH === trim( (string) $wp->request, '/' );

		if ( ! $by_path && '1' !== (string) get_query_var( self::QUERY_VAR, '' ) ) {
			return;
		}

		$wp_query->is_404 = false;
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex' );

		echo self::xml( self::entries() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in xml().
		exit;
	}

	/**
	 * Every address the plugin owns that is worth indexing.
	 *
	 * @return array<int, array{loc:string, lastmod:string}>
	 */
	public static function entries(): array {
		$urls = [
			[ Router::url( self::PUBLIC_ROUTE ), '' ],
			[ Frontend::archive_url( PostTypes::VENUE ), '' ],
			[ home_url( '/' . Directory::BASE . '/' ), '' ],
			[ Calendar::url(), '' ],
		];

		foreach ( \DGL\Funding\Visibility::filter_types( PostTypes::enabled_keys(), true ) as $type ) {
			$urls[] = [ Frontend::archive_url( $type ), '' ];
		}

		$orgs = get_posts(
			[
				'post_type'      => PostTypes::ORG,
				'post_status'    => 'publish',
				'posts_per_page' => self::MAX_URLS,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			]
		);

		foreach ( $orgs as $id ) {
			if ( Directory::is_listed( (int) $id ) ) {
				$urls[] = [ \DGL\Org\DirectoryQuery::url( (int) $id ), (string) get_post_modified_time( 'c', true, (int) $id ) ];
			}
		}

		return self::normalise( $urls );
	}

	/**
	 * Drop empty and repeated addresses and cap the list. Pure.
	 *
	 * @param array<int, array{0:string, 1:string}> $urls [address, last modified] pairs.
	 * @return array<int, array{loc:string, lastmod:string}>
	 */
	public static function normalise( array $urls ): array {
		$seen = [];
		$out  = [];

		foreach ( $urls as [ $loc, $lastmod ] ) {
			if ( '' === $loc || isset( $seen[ $loc ] ) ) {
				continue;
			}

			$seen[ $loc ] = true;
			$out[]        = [ 'loc' => $loc, 'lastmod' => $lastmod ];

			if ( count( $out ) >= self::MAX_URLS ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * The sitemap document. Pure.
	 *
	 * @param array<int, array{loc:string, lastmod:string}> $entries
	 */
	public static function xml( array $entries ): string {
		$xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

		foreach ( $entries as $entry ) {
			$xml .= "\t<url><loc>" . htmlspecialchars( $entry['loc'], ENT_XML1 | ENT_QUOTES, 'UTF-8' ) . '</loc>';

			if ( '' !== $entry['lastmod'] ) {
				$xml .= '<lastmod>' . htmlspecialchars( $entry['lastmod'], ENT_XML1 | ENT_QUOTES, 'UTF-8' ) . '</lastmod>';
			}

			$xml .= "</url>\n";
		}

		return $xml . "</urlset>\n";
	}
}
