<?php
/**
 * What a list card says about an item: its chip, its picture, its meta line.
 *
 * The public lists show every item the same way, a square picture and three
 * lines, so the eye can run down them. This is the one place those lines
 * are decided, for the featured block and the rows alike.
 *
 * @package DGL
 */

declare( strict_types=1 );

namespace DGL\Frontend;

use DGL\Dashboard\View;
use DGL\Events\Cancel;
use DGL\Events\Series;
use DGL\PostTypes;
use DGL\Taxonomies;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class Cards {

	/** Words a minute, for the reading time on a story. */
	public const WORDS_PER_MINUTE = 200;

	/** The chip: the item's first topic, else what kind of thing it is. */
	public static function chip( WP_Post $post ): string {
		$terms = wp_get_object_terms( (int) $post->ID, Taxonomies::TOPIC, [ 'fields' => 'names', 'orderby' => 'name' ] );

		if ( is_array( $terms ) && [] !== $terms ) {
			return (string) $terms[0];
		}

		return Frontend::type_label( (string) $post->post_type );
	}

	/**
	 * The meta line, as segments the template joins with a slash.
	 *
	 * News: organisation, date, reading time. Events: when, where,
	 * organisation. Anything else: its date, where, organisation.
	 *
	 * @return string[]
	 */
	public static function meta( WP_Post $post ): array {
		$org  = Frontend::organisation( $post )['name'];
		$type = (string) $post->post_type;

		if ( PostTypes::NEWS === $type ) {
			return array_values( array_filter( [ $org, self::posted( $post ), self::reading_time( $post ) ] ) );
		}

		// Funding: who offers it, how much, and when it closes. The organisation
		// that posted it is no help when the weekly import posted it.
		if ( PostTypes::GRANT === $type ) {
			return self::fund_meta(
				(string) Frontend::value( $post, 'funder' ),
				Frontend::value( $post, 'amount_min' ),
				Frontend::value( $post, 'amount_max' ),
				(string) Frontend::value( $post, 'deadline' ),
				(bool) Frontend::value( $post, 'rolling_deadline' )
			);
		}

		// A venue: where it is and who runs it. When it was posted is no help.
		if ( PostTypes::VENUE === $type ) {
			$ward = \DGL\Schema\Types\Venue::wards()[ (string) Frontend::value( $post, 'ward' ) ] ?? '';

			return array_values( array_filter( [ $ward, $org ] ) );
		}

		/*
		 * The date of the thing itself is on the calendar leaf beside the
		 * row, so the line does not repeat it. What it does say is when the
		 * listing was posted, labelled, so nobody takes one date for the
		 * other. A series says its pattern, because the leaf can only show
		 * one date of it.
		 */
		$parts = [];

		if ( PostTypes::EVENT === $type && Cancel::is_cancelled( (int) $post->ID ) ) {
			$parts[] = __( 'Cancelled', 'dgl-platform' );
		}

		$rule = Series::rule_for( (int) $post->ID );

		if ( null !== $rule ) {
			$parts[] = \DGL\Events\Wording::with_times( $rule->to_meta(), $rule->start->format( 'Y-m-d H:i:s' ), '' );
		}

		// Events and courses say when they happen, in words, and leave out when
		// they were posted: two dates side by side read as one event with two.
		$when = in_array( $type, [ PostTypes::EVENT, PostTypes::TRAINING ], true ) ? self::when_line( $post ) : null;

		if ( null !== $when ) {
			$parts[] = $when['text'];
		}

		$parts[] = Frontend::where( $post );
		$parts[] = $org;

		if ( null === $when ) {
			/* translators: %s: a date like "24 Sep 2026". */
			$parts[] = sprintf( __( 'Posted: %s', 'dgl-platform' ), self::posted( $post ) );
		}

		return array_values( array_filter( $parts ) );
	}

	/**
	 * A fund's meta line: funder, "£300 to £20,000", "Closes 12 Dec 2026" or
	 * "Open all year". Pure, so it is tested.
	 *
	 * @param mixed $min
	 * @param mixed $max
	 * @return string[]
	 */
	public static function fund_meta( string $funder, $min, $max, string $deadline, bool $rolling ): array {
		$pounds = static fn( $v ): string => '£' . number_format( (float) $v );
		$min    = is_numeric( $min ) && (float) $min > 0 ? $min : null;
		$max    = is_numeric( $max ) && (float) $max > 0 ? $max : null;
		$amount = match ( true ) {
			null !== $min && null !== $max && (float) $min !== (float) $max => sprintf( /* translators: 1, 2: amounts. */ __( '%1$s to %2$s', 'dgl-platform' ), $pounds( $min ), $pounds( $max ) ),
			null !== $max => sprintf( /* translators: %s: an amount. */ __( 'Up to %s', 'dgl-platform' ), $pounds( $max ) ),
			null !== $min => sprintf( /* translators: %s: an amount. */ __( 'From %s', 'dgl-platform' ), $pounds( $min ) ),
			default       => '',
		};

		$closes = '';

		if ( $rolling ) {
			$closes = __( 'Open all year', 'dgl-platform' );
		} elseif ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ) {
			/* translators: %s: a date like "12 Dec 2026". */
			$closes = sprintf( __( 'Closes %s', 'dgl-platform' ), date( 'j M Y', (int) strtotime( $deadline . ' 12:00:00' ) ) ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date -- a calendar date with no time zone.
		}

		// A funder is a name, but some pages give a sentence: keep the name part.
		$funder = trim( (string) preg_split( '/\s*[(,;]|\s+-\s+/', $funder, 2 )[0] );
		$funder = mb_strlen( $funder ) > 60 ? rtrim( mb_substr( $funder, 0, 57 ) ) . '...' : $funder;

		return array_values( array_filter( [ $funder, $amount, $closes ] ) );
	}

	/**
	 * A fund's closing leaf: "Closes / DEC / 15", or "Open / all year" for a
	 * rolling fund, whose stored deadline is only a refresh date and must
	 * never be shown as a closing day. '' when there is neither.
	 */
	public static function fund_date_block( WP_Post $post ): string {
		$parts = self::fund_date_parts( (string) Frontend::value( $post, 'deadline' ), (bool) Frontend::value( $post, 'rolling_deadline' ) );

		if ( null === $parts ) {
			return '';
		}

		if ( $parts['rolling'] ) {
			return '<span class="dgl-date dgl-date--fund dgl-date--rolling" aria-hidden="true"><span class="dgl-date__label">' . esc_html__( 'Open', 'dgl-platform' ) . '</span><span class="dgl-date__all">' . esc_html__( 'all year', 'dgl-platform' ) . '</span></span>';
		}

		return sprintf(
			'<time class="dgl-date dgl-date--fund%s" datetime="%s" aria-hidden="true"><span class="dgl-date__label">%s</span><span class="dgl-date__month">%s</span><span class="dgl-date__day">%s</span></time>',
			$parts['soon'] ? ' dgl-date--soon' : '',
			esc_attr( $parts['iso'] ),
			esc_html__( 'Closes', 'dgl-platform' ),
			esc_html( $parts['month'] ),
			esc_html( $parts['day'] )
		);
	}

	/**
	 * Pure: what a fund's leaf says. Null with no usable date and not rolling.
	 * "Soon" is within fourteen days of $today.
	 *
	 * @return array{rolling:bool, month:string, day:string, iso:string, soon:bool}|null
	 */
	public static function fund_date_parts( string $deadline, bool $rolling, ?string $today = null ): ?array {
		if ( $rolling ) {
			return [ 'rolling' => true, 'month' => '', 'day' => '', 'iso' => '', 'soon' => false ];
		}

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $deadline ) ) {
			return null;
		}

		$ts    = (int) strtotime( $deadline . ' 12:00:00 UTC' );
		$today = $today ?? gmdate( 'Y-m-d' );
		$days  = (int) floor( ( $ts - (int) strtotime( $today . ' 12:00:00 UTC' ) ) / DAY_IN_SECONDS );

		return [
			'rolling' => false,
			'month'   => gmdate( 'M', $ts ),
			'day'     => gmdate( 'j', $ts ),
			'iso'     => $deadline,
			'soon'    => $days >= 0 && $days <= 14,
		];
	}

	/** The day it was published, as people write it. */
	public static function posted( WP_Post $post ): string {
		return (string) get_the_date( 'j M Y', $post );
	}

	/** "3 min read", from the story's words. Never under a minute. */
	public static function reading_time( WP_Post $post ): string {
		$words = str_word_count( wp_strip_all_tags( (string) $post->post_content . ' ' . (string) Frontend::value( $post, 'summary' ) ) );

		if ( 0 === $words ) {
			return '';
		}

		$minutes = max( 1, (int) ceil( $words / self::WORDS_PER_MINUTE ) );

		/* translators: %d: minutes. */
		return sprintf( __( '%d min read', 'dgl-platform' ), $minutes );
	}

	/**
	 * When it happens, in one short phrase: the next date of a series, or
	 * the start of a one-off, with the time when there is one.
	 */
	public static function when( WP_Post $post ): string {
		$id = (int) $post->ID;

		if ( Series::is_series( $id ) ) {
			$next = Series::next_dates( $id, 1 );

			if ( [] !== $next ) {
				/* translators: 1: a date like "Tue 29 Sep", 2: a time like "13:00". */
				return sprintf( __( 'Next %1$s, %2$s', 'dgl-platform' ), wp_date( 'D j M', $next[0]->start->getTimestamp() ), wp_date( 'H:i', $next[0]->start->getTimestamp() ) );
			}
		}

		foreach ( [ 'start_datetime', 'start_date', 'deadline' ] as $key ) {
			$raw = (string) Frontend::value( $post, $key );

			if ( '' !== $raw ) {
				return View::wall_date( $raw, str_contains( $raw, ':' ) );
			}
		}

		return '';
	}

	/**
	 * The span of a one-off event or a course: start, end, and where it
	 * stands today. Null for a series (its next date is on the leaf, its
	 * pattern in the meta line) and for an item with no date.
	 *
	 * @return array{line:string, text:string, to:string, time:string, iso:string, multi:bool, state:string}|null
	 */
	public static function span( WP_Post $post ): ?array {
		if ( Series::is_series( (int) $post->ID ) ) {
			return null;
		}

		foreach ( [ 'start_datetime' => 'end_datetime', 'start_date' => 'end_date' ] as $start_key => $end_key ) {
			$raw = trim( (string) Frontend::value( $post, $start_key ) );

			if ( '' === $raw ) {
				continue;
			}

			try {
				$tz    = wp_timezone();
				$start = new \DateTimeImmutable( $raw, $tz );
				$end_s = trim( (string) Frontend::value( $post, $end_key ) );
				$end   = '' === $end_s ? null : new \DateTimeImmutable( $end_s, $tz );
				$now   = new \DateTimeImmutable( 'now', $tz );
			} catch ( \Exception ) {
				return null;
			}

			return DateSpan::describe( $start, $end, $now, str_contains( $raw, ':' ) );
		}

		return null;
	}

	/**
	 * The one date sentence for an event or a course, with its machine
	 * date. A series says its next date; anything else its day or span.
	 * Null when there is nothing to say.
	 *
	 * @return array{text:string, iso:string}|null
	 */
	public static function when_line( WP_Post $post ): ?array {
		$span = self::span( $post );

		if ( null !== $span ) {
			return [ 'text' => $span['line'], 'iso' => $span['iso'] ];
		}

		$parts = self::date_parts( $post );
		$text  = self::when( $post );

		return null === $parts || '' === $text ? null : [ 'text' => $text, 'iso' => $parts['iso'] ];
	}

	/**
	 * The day an event or a course happens, as a calendar leaf: the month
	 * over the day number, and the time when there is one. A series shows
	 * its next date. Nothing for news, which has no date worth a glance.
	 *
	 * @return array{month:string, day:string, weekday:string, time:string, to:string, iso:string}|null
	 */
	public static function date_parts( WP_Post $post ): ?array {
		$id    = (int) $post->ID;
		$ts    = null;
		$timed = false;

		if ( Series::is_series( $id ) ) {
			$next = Series::next_dates( $id, 1 );

			if ( [] !== $next ) {
				$ts    = $next[0]->start->getTimestamp();
				$timed = true;
			}
		}

		if ( null === $ts ) {
			foreach ( [ 'start_datetime', 'start_date' ] as $key ) {
				$raw = trim( (string) Frontend::value( $post, $key ) );

				if ( '' !== $raw ) {
					try {
						$ts    = ( new \DateTimeImmutable( $raw, wp_timezone() ) )->getTimestamp();
						$timed = str_contains( $raw, ':' );
					} catch ( \Exception ) {
						$ts = null;
					}
					break;
				}
			}
		}

		if ( null === $ts ) {
			return null;
		}

		return [
			'month'   => (string) wp_date( 'M', $ts ),
			'day'     => (string) wp_date( 'j', $ts ),
			'weekday' => (string) wp_date( 'D', $ts ),
			'time'    => $timed ? (string) wp_date( 'H:i', $ts ) : '',
			'to'      => (string) ( self::span( $post )['to'] ?? '' ),
			'iso'     => (string) wp_date( $timed ? 'Y-m-d\\TH:i' : 'Y-m-d', $ts ),
		];
	}

	/**
	 * The calendar leaf as markup, or '' when there is no date. The words
	 * are already in the meta line, so the leaf is decoration to a screen
	 * reader and the machine-readable date rides on a <time>.
	 */
	public static function date_block( WP_Post $post ): string {
		$parts = self::date_parts( $post );

		if ( null === $parts ) {
			return '';
		}

		$off = PostTypes::EVENT === (string) $post->post_type && Cancel::is_cancelled( (int) $post->ID );

		// A span shows where it ends ("to 22 Oct"); a one-day event shows its time.
		$extra = '' !== $parts['to']
			? '<span class="dgl-date__to">' . esc_html( $parts['to'] ) . '</span>'
			: ( '' !== $parts['time'] ? '<span class="dgl-date__time">' . esc_html( $parts['time'] ) . '</span>' : '' );

		return sprintf(
			'<time class="dgl-date%s%s" datetime="%s" aria-hidden="true"><span class="dgl-date__month">%s</span><span class="dgl-date__day">%s</span>%s</time>',
			$off ? ' dgl-date--off' : '',
			'' !== $parts['to'] ? ' dgl-date--span' : '',
			esc_attr( $parts['iso'] ),
			esc_html( $parts['month'] ),
			esc_html( $parts['day'] ),
			$extra
		);
	}

	/**
	 * The picture, or a tile that stands in for one.
	 *
	 * @param string $size A registered image size.
	 * @param bool   $eager Whether the browser should fetch it at once (the featured picture).
	 */
	public static function picture( WP_Post $post, string $size = 'medium_large', bool $eager = false ): string {
		$image_id = (int) Frontend::value( $post, 'image' );

		// An item can name a picture whose file has since gone (the imported
		// stories often do). That counts as no picture.
		if ( $image_id > 0 ) {
			$img = wp_get_attachment_image( $image_id, $size, false, [ 'loading' => $eager ? 'eager' : 'lazy', 'alt' => '', 'class' => 'dgl-card__img' ] );

			if ( '' !== $img ) {
				return $img;
			}
		}

		$stand_in = self::stand_in( (string) $post->post_type, $size, $eager );

		if ( '' !== $stand_in ) {
			return $stand_in;
		}

		// No picture: a plain tile with one word for what it is, so the row keeps
		// its shape and nobody mistakes the gap for a broken image.
		$word = (string) strtok( Frontend::type_label( (string) $post->post_type ), ' ' );

		return '<span class="dgl-card__img dgl-card__img--none" aria-hidden="true"><span>' . esc_html( $word ) . '</span></span>';
	}

	/**
	 * The picture an administrator chose for news, events or training that
	 * have none of their own (Settings, Topic feed pictures), as an <img>;
	 * '' when none is chosen or the type has no setting.
	 */
	public static function stand_in( string $post_type, string $size = 'medium_large', bool $eager = false ): string {
		$key = array_search( $post_type, Feed::TYPES, true );

		if ( false === $key ) {
			return '';
		}

		$id = (int) get_option( sprintf( Feed::IMAGE_OPTION, (string) $key ), 0 );

		if ( $id <= 0 ) {
			return '';
		}

		return wp_get_attachment_image( $id, $size, false, [ 'loading' => $eager ? 'eager' : 'lazy', 'alt' => '', 'class' => 'dgl-card__img dgl-card__img--stand-in' ] );
	}

	/**
	 * The summary the member wrote, else the story's own first words. Trimmed
	 * to a listing's worth either way, so a pasted essay cannot run the row.
	 */
	public static function summary( WP_Post $post, int $words = 32 ): string {
		$text = trim( wp_strip_all_tags( (string) Frontend::value( $post, 'summary' ) ) );

		if ( '' === $text ) {
			$text = trim( wp_strip_all_tags( (string) $post->post_excerpt ) );
		}

		if ( '' === $text ) {
			$text = trim( wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ) );
		}

		return '' === $text ? '' : (string) wp_trim_words( $text, $words, '…' );
	}

	public static function has_picture( WP_Post $post ): bool {
		return (int) Frontend::value( $post, 'image' ) > 0;
	}
}
